module c2_server

go 1.25

require golang.org/x/sys v0.40.0 // indirect
