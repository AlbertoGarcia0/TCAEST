module c2_cifrador

go 1.25

require golang.org/x/sys v0.40.0 // indirect
